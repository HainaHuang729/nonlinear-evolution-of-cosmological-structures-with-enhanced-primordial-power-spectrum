"""Convert scientific density cache into aligned scientific and display VDB grids."""
import argparse
import json
from pathlib import Path
import numpy as np
try:
    import openvdb as vdb
except ImportError:
    import pyopenvdb as vdb

def convert(directory,resolution):
    directory=Path(directory); n=resolution
    arrays={'mass_density':np.load(directory/f'density_{n}.npy'),
            'overdensity':np.load(directory/f'overdensity_{n}.npy')}
    # A global, time-independent transfer function, separate from scientific grids.
    arrays['density']=np.maximum(np.log1p(arrays['overdensity'])-np.log(2.),0).astype(np.float32)
    grids=[]
    for name,data in arrays.items():
        grid=vdb.FloatGrid(); grid.name=name; grid.copyFromArray(data)
        grid.gridClass=vdb.GridClass.FOG_VOLUME
        grid.transform=vdb.createLinearTransform(voxelSize=1/n)
        grid.transform.postTranslate(tuple([-.5+.5/n]*3)); grids.append(grid)
    dest=directory/f'density_{n}.vdb'
    vdb.write(str(dest),grids=grids)
    print(dest,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('directory'); p.add_argument('--resolution',type=int,default=128)
    a=p.parse_args(); convert(a.directory,a.resolution)
