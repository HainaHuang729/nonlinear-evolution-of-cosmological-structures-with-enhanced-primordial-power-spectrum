"""Verify nested IDs, matching, minimum-image motion, and cache format costs."""
import io
import json
import time
import numpy as np
from common import settings, output, write_json

def main():
    cfg=settings(); root=output(); k=max(cfg['particles']['cohort_sizes'])
    canonical=np.fromfile(root/'cohorts'/f'particles_{k}.ids.u64',dtype='<u8')
    for size in cfg['particles']['cohort_sizes']:
        ids=np.fromfile(root/'cohorts'/f'particles_{size}.ids.u64',dtype='<u8')
        indices=np.fromfile(root/'cohorts'/f'particles_{size}.indices.u32',dtype='<u4')
        assert np.array_equal(canonical[indices],ids)
    frames=[]
    for snapshot in [55,56]:
        d=root/'particles'/f'snapshot_{snapshot:04d}'
        m=json.loads((d/'metadata.json').read_text())
        assert m['match_rate']==1 and m['missing_ids']==m['duplicate_ids']==0
        frames.append(np.fromfile(d/'position.f32',dtype='<f4').reshape(-1,3))
    x,y=frames; naive=y-x; delta=naive-np.rint(naive)
    wrapped=((x+delta+.5)%1)-.5
    # Float32 normalization/wrap error at boundaries is tolerated.
    error=wrapped-y; error-=np.rint(error)
    assert np.max(np.abs(error))<3e-7
    assert np.max(np.abs(delta))<=.5
    assert np.allclose((np.array([.49])+(.02)*.5+.5)%1-.5,-.5)
    timings={}
    for compressed in (False,True):
        buffer=io.BytesIO(); t=time.perf_counter()
        (np.savez_compressed if compressed else np.savez)(buffer,position=x)
        encode=time.perf_counter()-t; size=buffer.tell(); buffer.seek(0); t=time.perf_counter()
        with np.load(buffer) as f: back=f['position']
        assert np.array_equal(back,x)
        timings['npz_compressed' if compressed else 'npz']={'bytes':size,'encode_seconds':encode,'decode_seconds':time.perf_counter()-t}
    write_json(root/'pilot_validation.json',dict(nested_cohorts=True,selected_id_match_rate=1,
        particles_with_periodic_crossing=int(np.any(abs(naive)>.5,axis=1).sum()),
        max_endpoint_error=float(np.abs(error).max()),
        normalized_displacement_quantiles=np.quantile(np.linalg.norm(delta,axis=1),[0,.5,.99,1]).tolist(),
        format_test=timings,raw_position_bytes=x.nbytes))

if __name__=='__main__': main()
