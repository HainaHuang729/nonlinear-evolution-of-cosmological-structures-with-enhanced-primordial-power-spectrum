import os
assert os.environ.get('SLURM_JOB_ID')
from pathlib import Path
import json,sys,zipfile
base=Path('/project/tkcastrosim/HNHuang/project_21cmFast/blender_visualization')
dest=base/'output/preview/particle_priority'
# Reuse installed browser-test dependencies without changing the separate website.
site=base.parent/'article_data_page'
sys.path.insert(0,str(site/'.cache/packages'))
os.environ['PLAYWRIGHT_BROWSERS_PATH']=str(site/'.cache/browsers')
from playwright.sync_api import sync_playwright
checks=[]
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page(viewport={'width':1280,'height':720})
    for name,duration in [('fixed',71/12),('orbit',6)]:
        page.goto((dest/f'particles_{name}.mp4').as_uri());v=page.locator('video')
        v.evaluate('(v)=>{v.muted=true;return v.play()}');page.wait_for_function('document.querySelector("video").currentTime>0')
        assert abs(v.evaluate('(v)=>v.duration')-duration)<.1
        v.evaluate('(v)=>new Promise(r=>{v.pause();v.addEventListener("seeked",r,{once:true});v.currentTime=3;})')
        v.screenshot(path=str(dest/f'{name}_decoded.png'))
        checks.append({'video':name,'duration':v.evaluate('(v)=>v.duration'),'decode_seek':'passed'})
    b.close()
(dest/'video_validation.json').write_text(json.dumps(checks,indent=2))
# A small update archive overlays the existing full package; no simulation data duplicated.
with zipfile.ZipFile(base/'particle_priority_update.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    paths=[base/'output/preview/cosmic_evolution_demo.blend',base/'config/visualization.yaml',base/'output/visualization.json']
    paths+=list((base/'blender').glob('*.py'))
    paths+=[dest/f'particles_{mode}.mp4' for mode in ['fixed','orbit']]
    paths+=[dest/name for name in ['restrained_uniform.png','restrained_speed.png','cohorts_measurements.json','preview_manifest.json','scene_verification.json','video_validation.json']]
    for path in paths:z.write(path,str(Path('blender_visualization')/path.relative_to(base)))
    z.writestr('READ-ME.txt','Overlay this archive on the previously delivered full cosmic_evolution_mvp package. Keep the existing output/particles, output/cohorts and output/volumes caches. This update contains no HDF5 or replacement particle cache. Open blender_visualization/output/preview/cosmic_evolution_demo.blend with trusted scripts enabled. Particles ON, Volume OFF, uniform color, fixed camera. Volume remains manually switchable.\n')
print('MEDIA_VERIFIED',json.dumps(checks),flush=True)
print('UPDATE_ZIP_BYTES',(base/'particle_priority_update.zip').stat().st_size,flush=True)
