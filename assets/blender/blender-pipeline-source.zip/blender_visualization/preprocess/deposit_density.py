"""Mass-weighted periodic CIC over ALL particles, one HDF5 chunk at a time."""
import argparse
import time
import h5py
import numpy as np
from numba import njit
from common import settings, source, output, metadata, write_json

@njit(cache=True)
def deposit(grid, xyz, mass, box):
    n=grid.shape[0]
    for p in range(len(mass)):
        # Index i denotes cell centre (i+0.5)/n, not cell corner.
        u=(xyz[p]%box)/box*n-.5
        b=np.floor(u).astype(np.int64); t=u-b
        for dx in range(2):
            for dy in range(2):
                for dz in range(2):
                    w=(t[0] if dx else 1-t[0])*(t[1] if dy else 1-t[1])*(t[2] if dz else 1-t[2])
                    grid[(b[0]+dx)%n,(b[1]+dy)%n,(b[2]+dz)%n]+=mass[p]*w

def main():
    p=argparse.ArgumentParser(); p.add_argument('--config'); p.add_argument('--snapshot',type=int,required=True)
    p.add_argument('--resolution',type=int,default=128); a=p.parse_args(); cfg=settings(a.config)
    n=a.resolution
    if n not in (128,256): raise ValueError('MVP supports 128 and 256 only')
    grid=np.zeros((n,n,n),dtype=np.float64); total=0.; count=0; start=time.perf_counter()
    with h5py.File(source(cfg,a.snapshot),'r') as f:
        meta=metadata(f); box=np.asarray(meta['box_size']); step=cfg['particles']['chunk_rows']
        coords=f['PartType1/Coordinates']; masses=f['PartType1/Masses']
        for lo in range(0,len(coords),step):
            xyz=coords[lo:lo+step]; mass=masses[lo:lo+step].astype(np.float64)
            if not np.isfinite(xyz).all() or not np.isfinite(mass).all() or np.any(mass<0):
                raise ValueError('Invalid source coordinates or mass')
            deposit(grid,xyz,mass,box); total+=mass.sum(dtype=np.float64); count+=len(mass)
            if lo%(step*64)==0: print('density',a.snapshot,n,lo,len(coords),flush=True)
    error=abs(grid.sum()-total)/total
    if error>1e-10: raise RuntimeError(f'Mass conservation failure {error}')
    density=grid/(np.prod(box)/n**3)
    target=output()/'volumes'/f'snapshot_{a.snapshot:04d}'; target.mkdir(parents=True,exist_ok=True)
    np.save(target/f'density_{n}.npy',density.astype('<f4'))
    np.save(target/f'overdensity_{n}.npy',(grid/grid.mean()).astype('<f4'))
    meta.update(snapshot=a.snapshot,resolution=n,all_particles=count,total_mass=total,
        deposition='periodic cell-centered mass-weighted CIC',axis_order='xyz',
        mass_relative_error=error,density_units='source mass / comoving Mpc^3',
        elapsed_seconds=time.perf_counter()-start,
        normalized_voxel_center_transform={'scale':1/n,'translation':[-.5+.5/n]*3})
    write_json(target/f'metadata_{n}.json',meta)

if __name__=='__main__': main()
