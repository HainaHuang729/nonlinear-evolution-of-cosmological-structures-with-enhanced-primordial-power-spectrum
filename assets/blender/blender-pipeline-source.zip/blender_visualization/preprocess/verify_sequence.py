import json
import numpy as np
from common import settings,output,write_json

def main():
    cfg=settings(); root=output(); summaries=[]; previous=None; motion=[]
    for snapshot in range(57):
        d=root/'particles'/f'snapshot_{snapshot:04d}'
        m=json.loads((d/'metadata.json').read_text())
        assert m['missing_ids']==m['duplicate_ids']==0 and m['match_rate']==1
        assert (d/'position.f32').stat().st_size==12000000
        assert (d/'speed.f32').stat().st_size==4000000
        pos=np.fromfile(d/'position.f32',dtype='<f4')
        assert np.isfinite(pos).all() and pos.min()>=-.5 and pos.max()<=.5
        pos=pos.reshape(-1,3)
        if previous is not None:
            difference=pos-previous
            crossing=int(np.any(np.abs(difference)>.5,axis=1).sum())
            difference-=np.rint(difference)
            motion.append(dict(start=snapshot-1,end=snapshot,crossing_particles=crossing,
                max_minimum_image_distance=float(np.linalg.norm(difference,axis=1).max())))
        previous=pos
        summaries.append(dict(snapshot=snapshot,a=m['scale_factor'],z=m['redshift'],
            elapsed_seconds=m['elapsed_seconds'],missing=0,duplicate=0,match_rate=1))
    assert np.all(np.diff([x['a'] for x in summaries])>0)
    write_json(root/'sequence_validation.json',dict(snapshots=summaries,count=57,position_speed_bytes=912000000,
        adjacent_motion=motion,minimum_image_note='Nearest-image displacement, not proof against multiple wraps'))
    write_json(root/'visualization.json',cfg)
    write_json(root/'metadata.json',dict(schema_version=1,simulation=cfg['simulation'],
        canonical_particle_order='ascending uint64 ParticleID',byte_order='little',
        position=dict(dtype='float32',shape=[1000000,3],normalization='mod(x,BoxSize)/BoxSize - 0.5',
                      box_size_comoving_mpc=m['box_size']),
        scalar=dict(name='speed',dtype='float32',shape=[1000000],definition='norm(source Velocities)',
                    source_attributes=m['velocity_attributes']),
        cohorts=[dict(count=n,ids=f'cohorts/particles_{n}.ids.u64',
                      canonical_indices=f'cohorts/particles_{n}.indices.u32') for n in cfg['particles']['cohort_sizes']],
        snapshots=[dict(index=s['snapshot'],scale_factor=s['a'],redshift=s['z'],
                        directory=f"particles/snapshot_{s['snapshot']:04d}") for s in summaries],
        volumes=dict(snapshots=[0,28,56],resolution=128,axis_order='xyz',array_order='C',
                     extra_resolution=dict(snapshot=56,resolution=256),time_sampling='discrete; no interpolated volume')))

if __name__=='__main__': main()
