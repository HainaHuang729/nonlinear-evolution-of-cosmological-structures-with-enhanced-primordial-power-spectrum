"""Bounded-memory SWIFT readers. Execute only inside a Slurm allocation."""
import json
import os
from pathlib import Path
import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]

def settings(path=None):
    if not os.environ.get('SLURM_JOB_ID'):
        raise RuntimeError('Run preprocessing in an explicit Slurm allocation')
    return yaml.safe_load(Path(path or ROOT / 'config/visualization.yaml').read_text())

def source(cfg, index):
    s = cfg['simulation']
    return Path(s['root']) / f"{s['sequence']}_{index:04d}.hdf5"

def output():
    # Frozen per-job code copies retain a stable output destination.
    return Path(os.environ.get('BLENDER_OUTPUT', ROOT / 'output'))

def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)

def metadata(f):
    def attrs(group):
        return {k: np.asarray(v).tolist() if np.asarray(v).dtype.kind not in 'OS' else str(v)
                for k, v in f[group].attrs.items()}
    h = f['Header'].attrs
    return dict(box_size=np.asarray(h['BoxSize']).reshape(-1).tolist(),
                scale_factor=float(np.asarray(h['Scale-factor']).item()),
                redshift=float(np.asarray(h['Redshift']).item()),
                header=attrs('Header'), units=attrs('Units'),
                coordinate_attributes=attrs('PartType1/Coordinates'),
                velocity_attributes=attrs('PartType1/Velocities'))

def hash_ids(ids, seed):
    # SplitMix64: arithmetic intentionally wraps modulo 2**64.
    with np.errstate(over='ignore'):
        x = ids.astype(np.uint64) ^ np.uint64(seed)
        x = x + np.uint64(0x9e3779b97f4a7c15)
        x = (x ^ (x >> np.uint64(30))) * np.uint64(0xbf58476d1ce4e5b9)
        x = (x ^ (x >> np.uint64(27))) * np.uint64(0x94d049bb133111eb)
        return x ^ (x >> np.uint64(31))
