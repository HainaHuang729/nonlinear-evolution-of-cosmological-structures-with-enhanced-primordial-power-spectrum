import argparse
import json
from pathlib import Path
import numpy as np
import openvdb as vdb

p=argparse.ArgumentParser(); p.add_argument('root'); a=p.parse_args(); root=Path(a.root)
reports=[]
for snapshot,n in [(0,128),(28,128),(56,128),(56,256)]:
    directory=root/'volumes'/f'snapshot_{snapshot:04d}'
    grids,meta=vdb.readAll(str(directory/f'density_{n}.vdb')); grids={g.name:g for g in grids}
    assert set(grids)=={'density','overdensity','mass_density'}
    expected=np.load(directory/f'density_{n}.npy'); actual=np.zeros_like(expected)
    grids['mass_density'].copyToArray(actual)
    assert np.array_equal(expected,actual)
    accessor=grids['mass_density'].getAccessor()
    for ijk in [(1,2,3),(n//3,n//5,n//7)]:
        assert accessor.getValue(ijk)==float(expected[ijk]),('Axis mapping mismatch',ijk)
    center=grids['density'].transform.indexToWorld((0,0,0))
    assert np.allclose(center,[-.5+.5/n]*3)
    upper=grids['density'].transform.indexToWorld((n-1,n-1,n-1))
    assert np.allclose(upper,[.5-.5/n]*3)
    reports.append(dict(snapshot=snapshot,resolution=n,roundtrip_exact=True,asymmetric_xyz_probes_exact=True,
                        first_voxel_center=center,last_voxel_center=upper,
                        vdb_bytes=(directory/f'density_{n}.vdb').stat().st_size))
(root/'vdb_validation.json').write_text(json.dumps(reports,indent=2))
print(json.dumps(reports),flush=True)
