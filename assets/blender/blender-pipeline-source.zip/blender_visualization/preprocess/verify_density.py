"""Synthetic CIC invariants plus real full-particle density accounting."""
import json
import numpy as np
from common import settings,output,write_json
from deposit_density import deposit

def main():
    cfg=settings(); root=output(); grid=np.zeros((8,8,8))
    xyz=np.array([[0.,0.,0.],[1.,1.,1.],[.5,.5,.5]])
    mass=np.array([2.,3.,7.]); deposit(grid,xyz,mass,np.ones(3))
    assert abs(grid.sum()-12)<1e-12
    assert abs(grid[0,0,0]-5/8)<1e-12
    shifted=np.zeros_like(grid); deposit(shifted,xyz+np.array([1.,-2.,3.]),mass,np.ones(3))
    assert np.allclose(grid,shifted)
    findings=[]
    for snap,n in [(0,128),(28,128),(56,128),(56,256)]:
        d=root/'volumes'/f'snapshot_{snap:04d}'
        meta=json.loads((d/f'metadata_{n}.json').read_text())
        rho=np.load(d/f'density_{n}.npy'); over=np.load(d/f'overdensity_{n}.npy')
        assert meta['all_particles']==1073741824
        assert meta['mass_relative_error']<1e-10 and np.isfinite(rho).all()
        assert abs(over.mean(dtype=np.float64)-1)<1e-6
        findings.append(dict(snapshot=snap,resolution=n,source=meta,
            overdensity_quantiles=np.quantile(over,[0,.5,.9,.99,1]).tolist()))
    write_json(root/'density_validation.json',{'synthetic_periodicity_and_mass_test':True,'grids':findings})
    write_json(root/'visualization.json',cfg)

if __name__=='__main__': main()
