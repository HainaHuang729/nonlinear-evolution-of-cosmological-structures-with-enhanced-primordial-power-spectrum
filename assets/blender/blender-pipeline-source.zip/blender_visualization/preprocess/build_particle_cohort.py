"""Select exact nested hash-ranked cohorts; never use particle row identity."""
import argparse
import time
import h5py
import numpy as np
from common import settings, source, output, hash_ids, write_json

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--config'); p.add_argument('--snapshot', type=int, default=56)
    args = p.parse_args(); cfg = settings(args.config)
    sizes = sorted(cfg['particles']['cohort_sizes']); k = max(sizes)
    seed = cfg['particles']['seed']; step = cfg['particles']['chunk_rows']
    ids = np.empty(0, dtype=np.uint64); hashes = ids.copy(); start = time.perf_counter()
    with h5py.File(source(cfg,args.snapshot),'r') as f:
        ds = f['PartType1/ParticleIDs']; n = len(ds)
        for lo in range(0,n,step):
            block = ds[lo:lo+step]; h = hash_ids(block,seed)
            if len(hashes) == k:
                mask = h <= hashes.max(); block = block[mask]; h = h[mask]
            ids = np.concatenate((ids,block)); hashes = np.concatenate((hashes,h))
            if len(ids)>k:
                cutoff = np.partition(hashes,k-1)[k-1]
                keep = hashes <= cutoff
                ids,hashes = ids[keep],hashes[keep]
                if len(ids)>k:
                    ix = np.lexsort((ids,hashes))[:k]; ids,hashes = ids[ix],hashes[ix]
            if lo % (step*64)==0: print('cohort',lo,n,flush=True)
    rank = np.lexsort((ids,hashes)); ids = ids[rank]
    if len(np.unique(ids)) != k: raise RuntimeError('Duplicate selected ParticleIDs')
    target = output()/'cohorts'; target.mkdir(parents=True,exist_ok=True)
    canonical = np.sort(ids)
    for size in sizes:
        selected = np.sort(ids[:size]).astype('<u8')
        selected.tofile(target/f'particles_{size}.ids.u64')
        np.searchsorted(canonical,selected).astype('<u4').tofile(target/f'particles_{size}.indices.u32')
    write_json(target/'metadata.json',dict(seed=seed,hash='SplitMix64 xor seed',
        selection='smallest (hash, ParticleID)',canonical_order='ascending uint64 ParticleID',
        sizes=sizes,source=str(source(cfg,args.snapshot)),scanned_particles=n,
        elapsed_seconds=time.perf_counter()-start,global_uniqueness_verified=False))

if __name__=='__main__': main()
