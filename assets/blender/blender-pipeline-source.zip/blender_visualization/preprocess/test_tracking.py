"""Adversarial identity tests with uint64 IDs above float64's exact integer range."""
import os
import sys
import tempfile
from pathlib import Path
import h5py
import numpy as np
import yaml
from common import settings
import build_particle_cohort
from export_particle_frames import export

def main():
    settings() # Enforce compute-node execution before creating fixtures.
    with tempfile.TemporaryDirectory(prefix='tracking-',dir=Path(os.environ['BLENDER_OUTPUT'])) as tmp:
        root=Path(tmp); out=root/'out'; out.mkdir(); os.environ['BLENDER_OUTPUT']=str(out)
        cfg=dict(simulation=dict(sequence='test',root=str(root)),
            particles=dict(cohort_sizes=[2,4],seed=17,chunk_rows=3))
        ids=np.arange(9,dtype=np.uint64)+np.uint64(2**60)
        xyz=np.column_stack((np.arange(9)/10,np.zeros(9),np.zeros(9)))
        def create(index,order,replacement=None):
            with h5py.File(root/f'test_{index:04d}.hdf5','w') as f:
                h=f.create_group('Header'); h.attrs['BoxSize']=np.ones(3)
                h.attrs['Scale-factor']=.5+index*.1; h.attrs['Redshift']=1/(.5+index*.1)-1
                f.create_group('Units')
                f['PartType1/ParticleIDs']=ids[order] if replacement is None else replacement
                f['PartType1/Coordinates']=xyz[order]
                f['PartType1/Velocities']=np.tile([3.,4.,0.],(9,1))
        create(0,np.arange(9)); create(1,np.arange(8,-1,-1))
        config=root/'config.yaml'; config.write_text(yaml.safe_dump(cfg))
        sys.argv=['cohort','--config',str(config),'--snapshot','0']; build_particle_cohort.main()
        export(cfg,0); export(cfg,1)
        p=np.fromfile(out/'particles/snapshot_0000/position.f32',dtype='<f4')
        q=np.fromfile(out/'particles/snapshot_0001/position.f32',dtype='<f4')
        assert np.array_equal(p,q), 'Row permutation must not alter canonical particle identity'
        assert np.all(np.fromfile(out/'particles/snapshot_0001/speed.f32',dtype='<f4')==5)
        selected=np.fromfile(out/'cohorts/particles_4.ids.u64',dtype='<u8')
        assert selected.min()>=2**60
        modified=ids.copy(); modified[np.flatnonzero(ids==selected[0])[0]]=np.uint64(999)
        create(2,np.arange(9),modified)
        try: export(cfg,2)
        except ValueError: pass
        else: raise AssertionError('Missing selected ID was accepted')
        assert not (out/'particles/snapshot_0002/metadata.json').exists()
        modified=ids.copy(); unselected=np.flatnonzero(~np.isin(ids,selected))[0]; modified[unselected]=selected[0]
        create(3,np.arange(9),modified)
        try: export(cfg,3)
        except ValueError: pass
        else: raise AssertionError('Duplicate selected ID was accepted')
        assert not (out/'particles/snapshot_0003/metadata.json').exists()
    print('PASS: shuffled rows, uint64 precision, speed, missing/duplicate rejection',flush=True)

if __name__=='__main__': main()
