"""Resolve YAML for Blender's bundled Python without rereading simulation data."""
from common import settings, output, write_json

if __name__=='__main__':
    write_json(output()/'visualization.json',settings())
