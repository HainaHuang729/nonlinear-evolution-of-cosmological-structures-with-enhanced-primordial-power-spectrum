"""Full streamed ID matching; read coordinate/velocity chunks only after matches."""
import argparse
import time
import h5py
import numpy as np
from common import settings, source, output, metadata, write_json

def export(cfg,index):
    start=time.perf_counter(); k=max(cfg['particles']['cohort_sizes'])
    ids=np.fromfile(output()/'cohorts'/f'particles_{k}.ids.u64',dtype='<u8')
    if len(ids)!=k or np.any(ids[1:]<=ids[:-1]): raise ValueError('Invalid canonical cohort')
    counts=np.zeros(k,dtype=np.uint32); pos=np.empty((k,3),dtype='<f4'); speed=np.empty(k,dtype='<f4')
    step=cfg['particles']['chunk_rows']
    with h5py.File(source(cfg,index),'r') as f:
        meta=metadata(f); box=np.asarray(meta['box_size']); ds=f['PartType1/ParticleIDs']
        for lo in range(0,len(ds),step):
            block=ds[lo:lo+step]; ix=np.searchsorted(ids,block)
            valid=ix<k; rows=np.flatnonzero(valid)
            rows=rows[ids[ix[rows]]==block[rows]]; target=ix[rows]
            if len(rows):
                np.add.at(counts,target,1)
                xyz=f['PartType1/Coordinates'][lo:lo+step][rows]
                vel=f['PartType1/Velocities'][lo:lo+step][rows].astype(np.float64)
                if not np.isfinite(xyz).all() or not np.isfinite(vel).all():
                    raise ValueError('Nonfinite selected field')
                pos[target]=(xyz%box)/box-.5
                speed[target]=np.linalg.norm(vel,axis=1)
            if lo%(step*128)==0: print('export',index,lo,len(ds),flush=True)
    dest=output()/'particles'/f'snapshot_{index:04d}'; dest.mkdir(parents=True,exist_ok=True)
    meta.update(snapshot=index,source=str(source(cfg,index)),count=k,
        missing_ids=int((counts==0).sum()),duplicate_ids=int((counts>1).sum()),
        match_rate=float((counts>0).mean()),elapsed_seconds=time.perf_counter()-start,
        position_dtype='<f4',scalar_dtype='<f4',coordinate_transform='mod(x,BoxSize)/BoxSize - 0.5',
        scalar='speed',scalar_units='source velocity units',canonical_cohort=f'particles_{k}.ids.u64')
    write_json(dest/'matching.json',meta)
    if np.any(counts!=1): raise ValueError(f'ID mismatch in snapshot {index}')
    for name,a in [('position.f32',pos),('speed.f32',speed)]:
        tmp=dest/(name+'.tmp'); a.tofile(tmp); tmp.replace(dest/name)
    meta['speed_range']=[float(speed.min()),float(speed.max())]
    write_json(dest/'metadata.json',meta) # Completion marker written last.

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--config'); p.add_argument('--snapshots',type=int,nargs='+',required=True)
    args=p.parse_args(); cfg=settings(args.config)
    for index in args.snapshots: export(cfg,index)
