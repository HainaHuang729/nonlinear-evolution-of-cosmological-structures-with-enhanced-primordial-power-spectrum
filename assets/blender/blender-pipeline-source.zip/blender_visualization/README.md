# SWIFT → Blender MVP

本目录处理 BT `kp_10_ms_1.5_25_1024`。原始 HDF5 只读。
MVP 已实现并完成数据、场景重开、cohort 切换、VDB 和视频验收。
包含 57 帧的 1M 主缓存、100k/500k/1M 固定 cohort、三个 128³ VDB、晚期 256³ VDB，以及 14.2 秒预览。
GPU 显存与真实桌面 viewport FPS 尚未测量，实际 CPU 测量见 reports/blender_performance_report.md。

## 运行规则

本集群所有 Python、验证、渲染都必须通过 Slurm。请从项目根目录提交
`blender_visualization/slurm/*.sbatch`；脚本指定 CPU、内存、时间和日志。
每个任务在 runs/JOBID 保存只读代码与配置副本。不要修改正在执行的 launcher。
software/ 是本地独立依赖，不改现有科研环境。

配置见 config/visualization.yaml。数据缓存写入 output/。
Blender 读取由 YAML 解析生成的 output/visualization.json，避免在 Blender 内额外安装 PyYAML。
仅改视觉参数后，可从项目根目录提交 `sbatch blender_visualization/slurm/resolve_config.sbatch`，再重建场景，无须重读 HDF5。
先 build_particle_cohort，再 export_particle_frames；只有两帧验证成功后扩展序列。
改变 seed、simulation 或 canonical cohort 后必须使用新的 BLENDER_OUTPUT 目录，不能混用旧帧。
cohort 是全体 ID 的 SplitMix64 排名，100k ⊂ 500k ⊂ 1M。
输出 ID 为 little-endian uint64，位置和 speed 为 little-endian float32。
所有帧均按相同升序 ParticleID 排列；匹配失败不会发布完成标记。

## 缓存格式

```text
output/
  cohorts/particles_{100000,500000,1000000}.ids.u64
  cohorts/particles_*.indices.u32
  cohorts/metadata.json
  particles/snapshot_0055/{position.f32,speed.f32,metadata.json,matching.json}
  particles/snapshot_0056/...
  volumes/snapshot_0000/{density_128.npy,overdensity_128.npy,density_128.vdb,metadata_128.json}
  volumes/snapshot_0028/...
  volumes/snapshot_0056/...
  preview/*.blend
```

位置数组 shape=(1000000,3)，单位盒 [-0.5,0.5)，原始 BoxSize/单位/a/z 在各帧 metadata。
speed 是原始 velocity 三维模，源速度的单位/scale-factor 指数保留在 metadata。
较小 cohort 用 indices 从 1M 缓存提取，不另存重复坐标。
IDs 不进 Blender 的浮点 attribute，避免 uint64 精度损失。

## Blender 中打开

应一起复制整个 blender_visualization/ 的 blender/ 和 output/，保持相对路径。
场景使用外部帧缓存，.blend 不是独立动画文件。
恢复动画 handler 需要允许本项目可信 Python 脚本执行，或明确使用
`blender --enable-autoexec output/preview/场景.blend` 启动。不要对不可信文件启用自动执行。
一份网格顶点通过 Geometry Nodes Mesh to Points 变为可渲染点。
frame_change handler 只保留 current/next 缓存，用 minimum-image 插值后回卷周期盒。
渲染锁定界面，避免后台更新网格与界面访问并发。

载入场景并启用可信脚本后，可以在 Blender Python Console 切换质量档：

```python
import import_particle_animation as p
p.set_cohort_size(100000)   # 或 500000 / 1000000
```

这会同步调整网格和 canonical 索引；不要单独手改对象的 cohort_size custom property。
在 Outliner 中切换 Particles / Volume collection 的视口和渲染开关，即可选择三种模式。

三帧 volume MVP 是离散切换，不代表完整 57 帧 volume 动画。
画面会分别标注粒子时间和当前离散 volume 的红移，避免把不同时间状态误当同帧数据。
粒子动画中间帧按 scale factor 线性插值并明确标记；只在真实 snapshot 上显示精确源 a/z。
最小镜像插值假设相邻存储时刻每轴真实位移小于半盒，两个端点不能证明未多次绕盒。

## 与网页共享

共享 cohort、canonical 排序、归一化坐标、speed、物理时间/单位和科学密度网格。
VDB、Geometry Nodes、材质与 Blender handlers 为 Blender 专用。

## 版本与性能边界

采用 Blender 4.5.3 LTS + OpenVDB 12。OpenVDB 13 输出的 file format 225
超出该 Blender 的读取版本范围；实际试验发现后已固定转换环境为 vdb12-env。
计算节点没有成功分配 GPU 时，Eevee 通过软件 OpenGL 离屏渲染；此速度不代表桌面 GPU。
生成的短视频为 100k 嵌套 cohort 的低分辨率预览；最终 demo .blend 保留 1M cohort。

## 下载到本地

打包完成后，在你自己的电脑终端执行（使用 runbook 中已有 SSH 主机别名）：

```bash
scp cuhk-via-vm:/oss06/data/project/tkcastrosim/HNHuang/project_21cmFast/blender_visualization/cosmic_evolution_mvp.tar.gz .
tar -xzf cosmic_evolution_mvp.tar.gz
```

然后用本机 Blender 打开 `blender_visualization/output/preview/cosmic_evolution_demo.blend`。
场景打开时停在晚期，便于先看到完整 cosmic web；按 Shift+Left 回到起点，再按空格播放。
完整目录包含播放所需的外部 cache，不需要下载原始十亿粒子 HDF5，也无需下载服务器 software/。
