"""Audit the saved scene, cache manifest and encoded preview video."""
import json
import sys
from pathlib import Path
import bpy

root=Path(sys.argv[sys.argv.index('--')+1]); scene=bpy.context.scene
manifest=json.loads((root/'metadata.json').read_text())
assert len(manifest['snapshots'])==57
assert scene.frame_start==1 and scene.frame_end==281
assert bpy.data.objects['Particles']['cohort_size']==1000000
movie=root/'preview/demo/cosmic_evolution_preview.mp4'
clip=bpy.data.movieclips.load(str(movie))
assert clip.frame_duration==71,(clip.frame_duration,movie)
assert list(clip.size)==[640,360],clip.size
fps=float(getattr(clip,'fps',5))
duration=clip.frame_duration/fps
assert 10<=duration<=20,(duration,fps)
checks=json.loads((root/'camera_validation.json').read_text())
assert all(min(c['x']+c['y'])>=.02 and max(c['x']+c['y'])<=.98 for c in checks)
report=dict(scene=str(Path(bpy.data.filepath).name),snapshots=57,cohort_size=1000000,
    timeline=[scene.frame_start,scene.frame_end],scene_fps=scene.render.fps,
    video_frames=clip.frame_duration,video_size=list(clip.size),video_fps=fps,video_duration_seconds=duration,
    video_bytes=movie.stat().st_size,video_cohort=100000,camera_box_fits=True)
(root/'delivery_validation.json').write_text(json.dumps(report,indent=2))
print('DELIVERY_VERIFIED',json.dumps(report),flush=True)
