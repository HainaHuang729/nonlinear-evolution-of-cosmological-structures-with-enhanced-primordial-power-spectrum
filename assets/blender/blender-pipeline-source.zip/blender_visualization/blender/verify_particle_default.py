import json,time,sys
from pathlib import Path
import bpy
root=Path(sys.argv[sys.argv.index('--')+1]);scene=bpy.context.scene
assert scene.render.engine=='BLENDER_EEVEE_NEXT'
assert scene['display_direction']=='particle-first'
assert scene.camera.animation_data is None
assert bpy.data.collections['Volume'].hide_render and bpy.data.collections['Volume'].hide_viewport
assert not bpy.data.collections['Particles'].hide_render
assert bpy.data.objects['Particles']['cohort_size']==1000000
assert bpy.data.objects['Particles']['color_mode']=='uniform'
assert not scene.use_nodes and not scene.camera.data.dof.use_dof
scene.frame_set(281);bpy.context.view_layer.update()
assert '1,000,000 / 1,073,741,824' in bpy.data.objects['ParticleSampleNote'].data.body
assert 'z = 0.000' in bpy.data.objects['CosmicTime'].data.body
scene.render.filepath=str(root/'preview/particle_priority/default_eevee_1080.png')
t=time.perf_counter();bpy.ops.render.render(write_still=True)
report={'status':'passed','engine':scene.render.engine,'backend':'CPU software rendering; no GPU allocated',
'render_seconds':time.perf_counter()-t,'resolution':[1920,1080],'cohort':1000000,'viewport_fps':None}
(root/'preview/particle_priority/default_verification.json').write_text(json.dumps(report,indent=2));print('VERIFIED',json.dumps(report),flush=True)
