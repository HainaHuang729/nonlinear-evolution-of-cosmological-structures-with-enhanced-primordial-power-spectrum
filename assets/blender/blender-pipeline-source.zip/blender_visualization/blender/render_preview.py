"""Render a short preview or representative modes from an existing trusted scene."""
import argparse
import json
import sys
import time
from pathlib import Path
import bpy

p=argparse.ArgumentParser(); p.add_argument('--output',required=True); p.add_argument('--video',action='store_true')
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]); dest=Path(a.output); dest.mkdir(parents=True,exist_ok=True)
scene=bpy.context.scene; scene.render.resolution_x=640; scene.render.resolution_y=360
scene.render.resolution_percentage=100; scene.render.use_lock_interface=True
if hasattr(scene,'eevee') and hasattr(scene.eevee,'taa_render_samples'):
    scene.eevee.taa_render_samples=16
results=[]
for frame,label in [(1,'early'),(141,'middle'),(281,'late')]:
    scene.frame_set(frame)
    for mode in ['particles','volume','hybrid']:
        bpy.data.collections['Particles'].hide_render=mode=='volume'
        bpy.data.collections['Volume'].hide_render=mode=='particles'
        import import_volume_animation
        import_volume_animation.update_volume(scene)
        scene.render.filepath=str(dest/f'{label}_{mode}.png'); t=time.perf_counter()
        bpy.ops.render.render(write_still=True)
        results.append(dict(frame=frame,mode=mode,seconds=time.perf_counter()-t))
bpy.data.collections['Particles'].hide_render=False; bpy.data.collections['Volume'].hide_render=False
if a.video:
    # Preview video uses the nested 100k cohort; saved demo scene remains 1M.
    obj=bpy.data.objects['Particles']; old=obj.data
    mesh=bpy.data.meshes.new('Preview100k'); mesh.vertices.add(100000)
    mesh.attributes.new('speed','FLOAT','POINT'); obj.data=mesh; obj['cohort_size']=100000
    bpy.data.meshes.remove(old)
    # Keep original timeline coverage, render every fourth simulation-animation frame.
    scene.frame_step=4; scene.render.fps=5
    scene.render.image_settings.file_format='FFMPEG'; scene.render.ffmpeg.format='MPEG4'
    scene.render.ffmpeg.codec='H264'; scene.render.filepath=str(dest/'cosmic_evolution_preview.mp4')
    t=time.perf_counter(); bpy.ops.render.render(animation=True)
    results.append(dict(video_seconds=time.perf_counter()-t,video_cohort=100000,
                        video_note='Nested 100k preview; saved interactive demo remains 1M'))
(dest/'preview_timings.json').write_text(json.dumps(results,indent=2))
