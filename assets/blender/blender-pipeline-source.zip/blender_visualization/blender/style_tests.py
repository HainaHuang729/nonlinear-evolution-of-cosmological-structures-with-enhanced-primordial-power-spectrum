import json
import sys
import time
from pathlib import Path
import bpy

root=Path(sys.argv[sys.argv.index('--')+1]); dest=root/'preview'/'styles'; dest.mkdir(parents=True,exist_ok=True)
scene=bpy.context.scene; scene.frame_set(6); scene.render.resolution_x=640; scene.render.resolution_y=360
scene.eevee.taa_render_samples=16
group=bpy.data.objects['Particles'].modifiers['EmissivePoints'].node_group
point=next(n for n in group.nodes if n.bl_idname=='GeometryNodeMeshToPoints')
emission=next(n for n in bpy.data.materials['SpeedEmission'].node_tree.nodes if n.bl_idname=='ShaderNodeEmission')
scene.use_nodes=True; tree=scene.node_tree; tree.nodes.clear()
source=tree.nodes.new('CompositorNodeRLayers'); glow=tree.nodes.new('CompositorNodeGlare')
glow.glare_type='FOG_GLOW'; glow.quality='HIGH'; glow.threshold=1.; glow.size=6
out=tree.nodes.new('CompositorNodeComposite'); tree.links.new(source.outputs['Image'],glow.inputs['Image']); tree.links.new(glow.outputs['Image'],out.inputs['Image'])
results=[]
for variant in ['baseline','larger_points','stronger_emission','subtle_glow','depth_of_field']:
    point.inputs['Radius'].default_value=.0008 if variant=='larger_points' else .00045
    emission.inputs['Strength'].default_value=4 if variant=='stronger_emission' else 2
    scene.use_nodes=variant=='subtle_glow'
    scene.camera.data.dof.use_dof=variant=='depth_of_field'
    scene.camera.data.dof.focus_distance=scene.camera.location.length
    scene.camera.data.dof.aperture_fstop=2.8
    scene.render.filepath=str(dest/f'{variant}.png'); t=time.perf_counter(); bpy.ops.render.render(write_still=True)
    results.append(dict(variant=variant,seconds=time.perf_counter()-t))
(dest/'timings.json').write_text(json.dumps(results,indent=2))
