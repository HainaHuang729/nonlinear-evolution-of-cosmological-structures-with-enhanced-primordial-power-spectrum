"""Bounded particle-only experiments using existing caches; no HDF5 access."""
import argparse,json,math,sys,time,resource,socket
from pathlib import Path
import bpy
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import import_particle_animation as p
import import_volume_animation as v
args=argparse.ArgumentParser();args.add_argument('--phase',choices=['styles','cohorts','preview','verify'],required=True)
args.add_argument('--root',required=True);args.add_argument('--gpu',action='store_true');a=args.parse_args(sys.argv[sys.argv.index('--')+1:])
root=Path(a.root).resolve();dest=root/'preview/particle_priority';dest.mkdir(exist_ok=True)
scene=bpy.context.scene;p.register()
# Keep volume available, but never render it during these experiments.
bpy.data.collections['Volume'].hide_render=True;bpy.data.collections['Volume'].hide_viewport=True
bpy.data.collections['Particles'].hide_render=False;bpy.data.collections['Particles'].hide_viewport=False
scene.use_nodes=False;scene.camera.data.dof.use_dof=False
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(0,0,0,1)
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=1920;scene.render.resolution_y=1080;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.use_lock_interface=True
scene.view_settings.view_transform='AgX';scene.view_settings.exposure=-.3
scene.camera.animation_data_clear()
def camera(angle=-.9,radius=3.8):
    cam=scene.camera;cam.location=(radius*math.cos(angle),radius*math.sin(angle),radius*.45)
    cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler()
camera()
if 'ParticleSampleNote' not in bpy.data.objects:
    text=bpy.data.objects['CosmicTime'];note=text.copy();note.data=text.data.copy();scene.collection.objects.link(note)
    note.name='ParticleSampleNote';note.location=(-.32,-.225,-1);note.scale=(.012,)*3
bpy.data.objects['CosmicTime'].location=(-.32,.19,-1)
bpy.data.objects['CosmicTime'].scale=(.018,)*3
bpy.data.objects['ParticleSampleNote'].location=(-.32,.162,-1)
bpy.data.objects['ParticleSampleNote'].scale=(.010,)*3
if a.gpu:
    prefs=bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type='CUDA';prefs.get_devices()
    for device in prefs.devices:device.use=device.type=='CUDA'
    assert any(d.type=='CUDA' for d in prefs.devices),'No CUDA device; refuse GPU claim'
    scene.cycles.device='GPU'
results=[]
def render(name,frame,mode,radius,emission,exposure):
    p.set_appearance(mode,radius,emission,1000.);scene.view_settings.exposure=exposure
    t=time.perf_counter();scene.frame_set(frame);bpy.context.view_layer.update();latency=time.perf_counter()-t
    scene.render.filepath=str(dest/(name+'.png'));t=time.perf_counter();bpy.ops.render.render(write_still=True)
    row=dict(name=name,frame=frame,cohort=int(bpy.data.objects['Particles']['cohort_size']),mode=mode,radius=radius,
        emission=emission,exposure=exposure,render_seconds=time.perf_counter()-t,frame_change_seconds=latency,
        resolution=[scene.render.resolution_x,scene.render.resolution_y],engine=scene.render.engine,device=scene.cycles.device,
        samples=scene.cycles.samples,denoising=False,hostname=socket.gethostname(),viewport_fps=None,
        peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    results.append(row);(dest/(a.phase+('_gpu' if a.gpu else '')+'_measurements.json')).write_text(json.dumps(results,indent=2))
    print('MEASURE',json.dumps(row),flush=True)
if a.phase=='styles':
    p.set_cohort_size(1000000)
    for style,r,e,x in [('baseline',.00045,2.,0.),('fine',.0003,2.,0.),('restrained',.0003,1.,-.3)]:
        for mode in ['uniform','speed']:render(style+'_'+mode,281,mode,r,e,x)
elif a.phase=='cohorts':
    for size in [100000,500000,1000000]:
        p.set_cohort_size(size)
        latencies=[]
        for frame in [276,277,278,279,280,281]:
            t=time.perf_counter();scene.frame_set(frame);bpy.context.view_layer.update();latencies.append(time.perf_counter()-t)
        render(f'cohort_{size}'+('_gpu' if a.gpu else ''),281,'uniform',.0003,1.,-.3)
        results[-1]['frame_change_series_seconds']=latencies
        (dest/(a.phase+('_gpu' if a.gpu else '')+'_measurements.json')).write_text(json.dumps(results,indent=2))
    if not a.gpu:
        for frame,label in [(1,'early'),(141,'middle')]:render(label+'_uniform',frame,'uniform',.0003,1.,-.3)
        for frame,label in [(1,'early'),(141,'middle')]:render(label+'_speed',frame,'speed',.0003,1.,-.3)
elif a.phase=='preview':
    # After the 1080p comparison: 1M, 720p, separate fixed/orbit clips with identical timing.
    p.set_cohort_size(1000000);p.set_appearance('uniform',.0003,1.,1000.)
    scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.cycles.samples=16
    for mode in ['fixed','orbit']:
        frames=list(range(1,282,4)) if mode=='fixed' else [281]*72
        for i,frame in enumerate(frames):
            camera(-.9 if mode=='fixed' else -.9+.35*i/(len(frames)-1))
            render(f'{mode}_{i:03d}',frame,'uniform',.0003,1.,-.3)
    # Default scene is fixed camera, particle-first; preserve old Hybrid as a separate backup.
    camera();scene.frame_set(281);scene.render.resolution_x=1920;scene.render.resolution_y=1080
    scene.render.engine='BLENDER_EEVEE_NEXT';scene.eevee.taa_render_samples=16
    scene['display_direction']='particle-first';scene['camera_mode']='fixed'
    scene['sample_disclosure']='Fixed ParticleID cohort; not all 1024^3 particles'
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type=='VIEW_3D':
                area.spaces.active.region_3d.view_rotation=scene.camera.rotation_euler.to_quaternion()
    bpy.ops.wm.save_as_mainfile(filepath=str(root/'preview/cosmic_evolution_demo.blend'))
    # Encode PNGs in a separate scene. Do not let particle handlers run on the VSE timeline.
    bpy.app.handlers.frame_change_pre.clear()
    for mode,count in [('fixed',71),('orbit',72)]:
        enc=bpy.data.scenes.new('Encode_'+mode);bpy.context.window.scene=enc
        enc.render.resolution_x=1280;enc.render.resolution_y=720;enc.render.resolution_percentage=100
        enc.render.fps=12;enc.frame_start=1;enc.frame_end=count
        enc.sequence_editor_create()
        strip=enc.sequence_editor.strips.new_image(mode,str(dest/f'{mode}_000.png'),channel=1,frame_start=1)
        for i in range(1,count):strip.elements.append(f'{mode}_{i:03d}.png')
        enc.render.image_settings.file_format='FFMPEG';enc.render.ffmpeg.format='MPEG4';enc.render.ffmpeg.codec='H264'
        enc.render.ffmpeg.constant_rate_factor='HIGH';enc.render.filepath=str(dest/f'particles_{mode}.mp4')
        bpy.ops.render.render(animation=True)
        clip=bpy.data.movieclips.load(str(dest/f'particles_{mode}.mp4'))
        assert clip.frame_duration==count and list(clip.size)==[1280,720]
    (dest/'preview_manifest.json').write_text(json.dumps({'cohort':1000000,'resolution':[1280,720],'fps':12,
        'fixed':{'frames':71,'seconds':71/12,'scene_frames':list(range(1,282,4)),'camera':'fixed'},
        'orbit':{'frames':72,'seconds':6,'snapshot':56,'camera_radians':.35},'gpu':False},indent=2))
elif a.phase=='verify':
    p.set_cohort_size(1000000)
    checks=[]
    for size in [100000,500000,1000000]:
        p.set_cohort_size(size)
        for frame,snapshot in [(1,0),(281,56)]:
            scene.frame_set(frame);bpy.context.view_layer.update()
            indices=np.fromfile(root/'cohorts'/f'particles_{size}.indices.u32',dtype='<u4')
            expected=np.fromfile(root/'particles'/f'snapshot_{snapshot:04d}'/'position.f32',dtype='<f4').reshape(-1,3)[indices]
            actual=np.empty(size*3,dtype=np.float32);bpy.data.objects['Particles'].data.vertices.foreach_get('co',actual)
            assert np.array_equal(actual.reshape(-1,3),expected)
            assert 'Fixed-ID sample' in bpy.data.objects['ParticleSampleNote'].data.body
            checks.append([size,frame,'exact'])
    assert bpy.data.collections['Volume'].hide_render and bpy.data.collections['Volume'].hide_viewport
    assert bpy.data.objects['Particles']['color_mode']=='uniform'
    volume=bpy.data.collections['Volume'];volume.hide_render=False;volume.hide_viewport=False
    p.update_frame(scene);v.update_volume(scene)
    assert sum(not o.hide_render for o in volume.objects)==1
    volume.hide_render=True;volume.hide_viewport=True;p.update_frame(scene);v.update_volume(scene)
    assert 'Volume z' not in bpy.data.objects['CosmicTime'].data.body
    (dest/'scene_verification.json').write_text(json.dumps({'status':'passed','cache_endpoints':checks,'volume_manual_toggle':True,'viewport_fps':None},indent=2))
