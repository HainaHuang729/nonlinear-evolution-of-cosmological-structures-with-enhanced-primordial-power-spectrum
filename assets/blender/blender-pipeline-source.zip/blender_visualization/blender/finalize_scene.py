"""Prepare a useful opening view without changing simulation caches."""
import bpy
import itertools
import json
import math
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
scene=bpy.context.scene
camera=scene.camera; camera.animation_data_clear()
for fraction,radius in [(0,3.8),(.4,3.3),(.7,2.6),(1,3.8)]:
    angle=-.9+fraction*.9
    camera.location=(radius*math.cos(angle),radius*math.sin(angle),radius*.45)
    camera.rotation_euler=(-camera.location).to_track_quat('-Z','Y').to_euler()
    frame=round(1+fraction*(scene.frame_end-1))
    camera.keyframe_insert(data_path='location',frame=frame)
    camera.keyframe_insert(data_path='rotation_euler',frame=frame)
checks=[]
for frame in [scene.frame_start,scene.frame_end]:
    scene.frame_set(frame); bpy.context.view_layer.update()
    projected=[world_to_camera_view(scene,camera,Vector(v)) for v in itertools.product([-.5,.5],repeat=3)]
    bounds=dict(frame=frame,x=[min(v.x for v in projected),max(v.x for v in projected)],
                y=[min(v.y for v in projected),max(v.y for v in projected)])
    assert min(bounds['x']+bounds['y'])>=.02 and max(bounds['x']+bounds['y'])<=.98,bounds
    checks.append(bounds)
Path(bpy.path.abspath('//../camera_validation.json')).write_text(json.dumps(checks,indent=2))
scene.frame_set(scene.frame_end)
bpy.ops.object.select_all(action='DESELECT')
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            space=area.spaces.active
            space.region_3d.view_location=(0,0,0)
            space.region_3d.view_distance=4.2
            space.region_3d.view_rotation=scene.camera.rotation_euler.to_quaternion()
            space.region_3d.view_perspective='PERSP'
            space.shading.type='MATERIAL'
            space.shading.use_scene_world=True
            space.shading.use_scene_lights=True
            space.overlay.show_overlays=False
cfg=json.loads(Path(bpy.path.abspath('//../visualization.json')).read_text())
scene.render.resolution_x=cfg['render']['resolution_x']; scene.render.resolution_y=cfg['render']['resolution_y']
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
print('Final scene opens at late snapshot; Shift-Left returns to animation start',flush=True)
