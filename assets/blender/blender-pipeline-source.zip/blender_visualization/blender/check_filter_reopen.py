import sys,json
from pathlib import Path
import bpy
root=Path(sys.argv[sys.argv.index('--')+1]);obj=bpy.data.objects['Particles']
import import_particle_animation as p
assert hasattr(bpy.types,'SWIFT_PT_particle_filter')
assert obj.swift_speed_min==0
p.set_speed_threshold(500.);bpy.context.view_layer.update()
assert obj['visible_particle_count']==75900
assert obj.modifiers['EmissivePoints'][obj['speed_filter_socket']]==500.
p.set_speed_threshold(0.);assert obj['visible_particle_count']==1000000
assert len(obj.data.vertices)==1000000
(root/'preview/particle_priority/filter_reopen.json').write_text(json.dumps({'status':'passed','default_threshold':0,'threshold_500_visible':75900,'canonical_vertices':1000000},indent=2))
print('FILTER_REOPEN_PASSED',flush=True)
