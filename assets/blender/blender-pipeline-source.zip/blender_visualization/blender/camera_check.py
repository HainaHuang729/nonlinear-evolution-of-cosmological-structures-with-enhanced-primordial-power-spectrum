import itertools
import json
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
scene=bpy.context.scene
for frame in [scene.frame_start,scene.frame_end]:
    scene.frame_set(frame); bpy.context.view_layer.update()
    p=[world_to_camera_view(scene,scene.camera,Vector(v)) for v in itertools.product([-.5,.5],repeat=3)]
    print('CAMERA_CORNERS',json.dumps(dict(frame=frame,x=[min(v.x for v in p),max(v.x for v in p)],y=[min(v.y for v in p),max(v.y for v in p)])),flush=True)
