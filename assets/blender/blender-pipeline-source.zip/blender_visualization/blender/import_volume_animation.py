"""Load aligned VDB caches. Three MVP snapshots are explicitly discrete."""
from pathlib import Path
import json
import bpy
from bpy.app.handlers import persistent

@persistent
def update_volume(scene,*unused):
    label=bpy.data.objects.get('CosmicTime')
    if label: label.data.body=label.data.body.split('\n')[0]
    objects=[o for o in bpy.data.objects if o.type=='VOLUME' and 'snapshot_frame' in o]
    if not objects: return
    if 'Particles' in bpy.data.objects and 'particle_scale_factor' in scene:
        active=min(objects,key=lambda o:abs(o['source_scale_factor']-scene['particle_scale_factor']))['snapshot_frame']
    else:
        active=min(objects,key=lambda o:abs(o['snapshot_frame']-scene.frame_current))['snapshot_frame']
    for obj in objects:
        if obj.type=='VOLUME':
            obj.hide_render=obj['snapshot_frame']!=active
            obj.hide_viewport=obj['snapshot_frame']!=active
            collection=bpy.data.collections.get('Volume')
            if label and not obj.hide_render and collection and not collection.hide_render and not collection.hide_viewport:
                z=obj.get('source_redshift',0.)
                if abs(z)<1e-10: z=0.
                label.data.body+=f'\nVolume z = {z:.3f} (discrete cache)'

def create(root,snapshots,spacing=5,resolution=128,density_scale=.8,emission_strength=3.):
    collection=bpy.data.collections.new('Volume'); bpy.context.scene.collection.children.link(collection)
    material=bpy.data.materials.new('CosmicDensity'); material.use_nodes=True
    nodes=material.node_tree.nodes; nodes.clear(); links=material.node_tree.links
    attr=nodes.new('ShaderNodeAttribute'); attr.attribute_name='density'
    scale=nodes.new('ShaderNodeMath'); scale.operation='MULTIPLY'; scale.inputs[1].default_value=density_scale
    volume=nodes.new('ShaderNodeVolumePrincipled'); volume.inputs['Color'].default_value=(.2,.35,.65,1)
    volume.inputs['Emission Color'].default_value=(.07,.18,.45,1)
    if 'Density Attribute' in volume.inputs: volume.inputs['Density Attribute'].default_value=''
    out=nodes.new('ShaderNodeOutputMaterial'); links.new(attr.outputs['Fac'],scale.inputs[0])
    links.new(scale.outputs[0],volume.inputs['Density']); links.new(volume.outputs['Volume'],out.inputs['Volume'])
    glow=nodes.new('ShaderNodeMath'); glow.operation='MULTIPLY'; glow.inputs[1].default_value=emission_strength
    links.new(attr.outputs['Fac'],glow.inputs[0]); links.new(glow.outputs[0],volume.inputs['Emission Strength'])
    for snapshot in snapshots:
        path=Path(root)/'volumes'/f'snapshot_{snapshot:04d}'/f'density_{resolution}.vdb'
        if not path.exists(): raise FileNotFoundError(path)
        data=bpy.data.volumes.new(f'Density_{snapshot:04d}'); data.filepath=str(path)
        data.grids.load()
        if not data.grids.is_loaded or 'density' not in data.grids:
            raise RuntimeError(f'Blender failed to load density grid: {path}; {data.grids.error_message}')
        print('VDB_LOADED',snapshot,[grid.name for grid in data.grids],flush=True)
        obj=bpy.data.objects.new(data.name,data); collection.objects.link(obj); data.materials.append(material)
        obj['snapshot_frame']=1+snapshot*spacing
        meta=json.loads((path.parent/f'metadata_{resolution}.json').read_text())
        obj['source_redshift']=meta['redshift']; obj['source_scale_factor']=meta['scale_factor']
    if update_volume not in bpy.app.handlers.frame_change_pre: bpy.app.handlers.frame_change_pre.append(update_volume)
    update_volume(bpy.context.scene)
    return collection

if __name__=='__main__':
    import argparse
    import sys
    parser=argparse.ArgumentParser(); parser.add_argument('--root',required=True)
    parser.add_argument('--snapshots',type=int,nargs='+',default=[0,28,56])
    parser.add_argument('--resolution',type=int,default=128)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    create(args.root,args.snapshots,resolution=args.resolution)
