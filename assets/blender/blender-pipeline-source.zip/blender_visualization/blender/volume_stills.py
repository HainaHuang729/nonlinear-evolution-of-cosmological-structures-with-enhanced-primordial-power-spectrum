import sys
from pathlib import Path
import bpy
sys.path.insert(0,str(Path(__file__).resolve().parent))
import import_volume_animation as volume

root=Path(sys.argv[sys.argv.index('--')+1]); dest=root/'preview'/'volume_checks'; dest.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene; scene.render.engine='BLENDER_EEVEE_NEXT'
scene.render.resolution_x=640; scene.render.resolution_y=360; scene.render.resolution_percentage=100
scene.eevee.taa_render_samples=16
if hasattr(scene.eevee,'volumetric_tile_size'): scene.eevee.volumetric_tile_size='2'
world=bpy.data.worlds.new('Black'); world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(0,0,0,1); scene.world=world
bpy.ops.object.camera_add(location=(2.3,-1.3,1.2)); camera=bpy.context.object
camera.rotation_euler=(-camera.location).to_track_quat('-Z','Y').to_euler(); camera.data.lens=45; scene.camera=camera
volume.create(root,[0,28,56])
for snapshot in [0,28,56]:
    scene.frame_set(1+snapshot*5); scene.render.filepath=str(dest/f'volume_{snapshot:04d}.png')
    bpy.ops.render.render(write_still=True)
