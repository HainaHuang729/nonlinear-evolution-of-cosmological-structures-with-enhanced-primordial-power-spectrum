"""Measure actual rendering and a low-cost triangle-instance alternative."""
import json
import resource
import sys
import time
from pathlib import Path
import bpy
args=sys.argv[sys.argv.index('--')+1:]; root=Path(args[0]); size=int(args[1])
scene=bpy.context.scene; scene.frame_set(6); scene.render.resolution_x=640; scene.render.resolution_y=360
if 'Volume' in bpy.data.collections: bpy.data.collections['Volume'].hide_render=True
scene.render.resolution_percentage=100
obj=bpy.data.objects['Particles']; group=obj.modifiers['EmissivePoints'].node_group
results=[]; dest=root/'preview'/'benchmarks'; dest.mkdir(parents=True,exist_ok=True)
for representation in ['points','triangle_instances']:
    if representation=='triangle_instances':
        out=next(n for n in group.nodes if n.bl_idname=='NodeGroupOutput')
        points=next(n for n in group.nodes if n.bl_idname=='GeometryNodeMeshToPoints')
        primitive=group.nodes.new('GeometryNodeMeshCircle'); primitive.fill_type='NGON'
        primitive.inputs['Vertices'].default_value=3; primitive.inputs['Radius'].default_value=.00045
        material=group.nodes.new('GeometryNodeSetMaterial'); material.inputs['Material'].default_value=bpy.data.materials['SpeedEmission']
        instance=group.nodes.new('GeometryNodeInstanceOnPoints')
        instance.inputs['Rotation'].default_value=scene.camera.rotation_euler
        group.links.new(primitive.outputs['Mesh'],material.inputs['Geometry'])
        group.links.new(material.outputs['Geometry'],instance.inputs['Instance'])
        group.links.new(points.outputs['Points'],instance.inputs['Points'])
        group.links.new(instance.outputs['Instances'],out.inputs['Geometry'])
    scene.render.filepath=str(dest/f'{size}_{representation}.png'); t=time.perf_counter()
    bpy.ops.render.render(write_still=True)
    results.append(dict(size=size,representation=representation,render_seconds=time.perf_counter()-t,
        cumulative_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        resolution=[640,360],hardware='CPU software Eevee; no allocated GPU',
        caveat='Triangle instances are geometry-cost experiment; speed attribute propagation not qualified'))
(dest/f'{size}.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results),flush=True)
