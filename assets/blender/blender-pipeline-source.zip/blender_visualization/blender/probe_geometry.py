import bpy
import json
import time
import resource
report={'version':bpy.app.version_string}
try:
    cloud=bpy.data.pointclouds.new('Probe')
    report['native_pointcloud']={'points_count':len(cloud.points),
        'points_add_available':hasattr(cloud.points,'add'),
        'attributes':list(cloud.attributes.keys())}
except Exception as exc: report['native_pointcloud_error']=repr(exc)
print('GEOMETRY_PROBE',json.dumps(report),flush=True)
