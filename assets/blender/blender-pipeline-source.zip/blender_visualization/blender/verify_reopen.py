"""Executed after reopening saved .blend with trusted embedded bootstrap enabled."""
import json
import sys
from pathlib import Path
import bpy
import numpy as np
args=sys.argv[sys.argv.index('--')+1:]
root=Path(args[0]); scene=bpy.context.scene; obj=bpy.data.objects['Particles']
indices=np.fromfile(root/'cohorts'/f"particles_{obj['cohort_size']}.indices.u32",dtype='<u4')
results=[]
import import_particle_animation as animation
start=np.array([[.49,-.49,0.]],dtype=np.float32)
end=np.array([[-.49,.49,.1]],dtype=np.float32)
mid=animation.periodic_mix(start,end,.5)
assert np.allclose(mid,[[-.5,-.5,.05]],atol=1e-6),mid
for index in [0,len(obj['snapshots'])-1]:
    frame=1+index*obj['frames_per_snapshot']; scene.frame_set(frame)
    expected=np.fromfile(root/'particles'/f"snapshot_{obj['snapshots'][index]:04d}"/'position.f32',dtype='<f4').reshape(-1,3)[indices]
    actual=np.empty(expected.size,dtype=np.float32); obj.data.vertices.foreach_get('co',actual)
    error=float(np.abs(actual.reshape(-1,3)-expected).max())
    assert error<3e-7, (frame,error)
    results.append(dict(frame=frame,max_position_error=error))
original_size=obj['cohort_size']
for size in [100000,500000,1000000]:
    animation.set_cohort_size(size)
    assert len(obj.data.vertices)==size
    ids=np.fromfile(root/'cohorts'/f'particles_{size}.indices.u32',dtype='<u4')
    expected=np.fromfile(root/'particles'/f"snapshot_{obj['snapshots'][-1]:04d}"/'position.f32',dtype='<f4').reshape(-1,3)[ids]
    actual=np.empty(expected.size,dtype=np.float32); obj.data.vertices.foreach_get('co',actual)
    assert np.array_equal(actual.reshape(-1,3),expected)
    results.append(dict(switched_cohort=size,last_frame_exact=True))
animation.set_cohort_size(original_size)
(root/'preview'/f"reopen_{obj['cohort_size']}.json").write_text(json.dumps(results,indent=2))
print('REOPEN_VERIFIED',results,flush=True)
