import sys,json,time
from pathlib import Path
import bpy,numpy as np
root=Path(sys.argv[sys.argv.index('--')+1]);dest=root/'preview/particle_priority';scene=bpy.context.scene
import import_particle_animation as p
p.register();obj=bpy.data.objects['Particles'];group=obj.modifiers['EmissivePoints'].node_group
out=next(n for n in group.nodes if n.bl_idname=='NodeGroupOutput')
original=out.inputs['Geometry'].links[0].from_socket
convert=group.nodes.new('GeometryNodePointsToVertices')
group.links.new(original,convert.inputs['Points'])
def geometry_count():
    group.links.new(convert.outputs['Mesh'],out.inputs['Geometry'])
    bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();deps.update()
    evaluated=obj.evaluated_get(deps);mesh=evaluated.to_mesh();n=len(mesh.vertices);evaluated.to_mesh_clear()
    group.links.new(original,out.inputs['Geometry']);return n
checks=[]
for size in [100000,500000,1000000]:
    p.set_cohort_size(size)
    for frame in [277,281]:
        scene.frame_set(frame);speed=np.empty(size,dtype=np.float32);obj.data.attributes['speed'].data.foreach_get('value',speed)
        for threshold in [0.,200.,500.,float(speed.max())+1]:
            p.set_speed_threshold(threshold)
            expected=int(np.count_nonzero(speed>=threshold));actual=geometry_count()
            assert actual==expected,(size,frame,threshold,expected,actual)
            checks.append(dict(size=size,frame=frame,threshold=threshold,visible=actual))
# Exact equality test, without changing cached scalar files.
p.set_speed_threshold(200.);obj.data.attributes['speed'].data[0].value=200.;obj.data.update()
speed[0]=200.;assert geometry_count()==int(np.count_nonzero(speed>=200.))
group.nodes.remove(convert);p.set_speed_threshold(0.);scene.frame_set(281)
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=1920;scene.render.resolution_y=1080;scene.render.resolution_percentage=100
renders=[]
for threshold in [0.,200.,500.]:
    p.set_speed_threshold(threshold)
    scene.render.filepath=str(dest/f'speed_threshold_{int(threshold)}.png')
    t=time.perf_counter();bpy.ops.render.render(write_still=True)
    renders.append(dict(threshold=threshold,visible=obj['visible_particle_count'],render_seconds=time.perf_counter()-t))
p.set_speed_threshold(0.);scene.render.engine='BLENDER_EEVEE_NEXT'
bpy.ops.wm.save_as_mainfile(filepath=str(root/'preview/cosmic_evolution_demo.blend'))
(dest/'speed_filter_verification.json').write_text(json.dumps(dict(status='passed',checks=checks,equality_passed=True,renders=renders,viewport_fps=None),indent=2))
print('FILTER_VERIFIED',json.dumps(renders),flush=True)
