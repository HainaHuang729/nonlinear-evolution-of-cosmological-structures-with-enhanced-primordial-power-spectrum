"""External canonical-ID cache -> one mesh -> Geometry Nodes points.

Run using Blender --python, or import from build_scene.py. No per-particle objects.
"""
import json
import time
from pathlib import Path
import bpy
import numpy as np
from bpy.app.handlers import persistent

_cache={}

def frame_data(root,index,indices):
    key=(str(root),index,len(indices))
    if key not in _cache:
        directory=root/'particles'/f'snapshot_{index:04d}'
        pos=np.fromfile(directory/'position.f32',dtype='<f4').reshape(-1,3)[indices]
        scalar=np.fromfile(directory/'speed.f32',dtype='<f4')[indices]
        meta=json.loads((directory/'metadata.json').read_text())
        _cache[key]=(pos,scalar,meta)
    return _cache[key]

def periodic_mix(a,b,alpha):
    delta=b-a; delta-=np.rint(delta)
    # Endpoints are normalized and alpha is in [0,1], hence at most one wrap.
    # Avoid a costly remainder operation over all 3M float components.
    result=a+alpha*delta
    result-=result>=.5
    result+=result<-.5
    return result.astype(np.float32,copy=False)

@persistent
def update_frame(scene,*unused):
    obj=bpy.data.objects.get('Particles')
    if obj is None or 'cache_root' not in obj: return
    root=Path(bpy.path.abspath(obj['cache_root']))
    indices=np.fromfile(root/'cohorts'/f"particles_{obj['cohort_size']}.indices.u32",dtype='<u4')
    snapshots=list(obj['snapshots']); spacing=obj['frames_per_snapshot']
    t=max(0,min((scene.frame_current-1)/spacing,len(snapshots)-1))
    i=int(t); j=min(i+1,len(snapshots)-1); alpha=t-i
    if not obj.get('interpolation',True): alpha=0.
    p,s,m=frame_data(root,snapshots[i],indices)
    q,v,n=frame_data(root,snapshots[j],indices)
    xyz=periodic_mix(p,q,alpha)
    obj.data.vertices.foreach_set('co',xyz.ravel())
    obj.data.attributes['speed'].data.foreach_set('value',s*(1-alpha)+v*alpha)
    obj.data.update()
    keep={(str(root),snapshots[x],len(indices)) for x in (i,j)}
    for key in list(_cache):
        if key not in keep: del _cache[key]
    a=m['scale_factor']*(1-alpha)+n['scale_factor']*alpha
    scene['particle_scale_factor']=a
    label=bpy.data.objects.get('CosmicTime')
    if label:
        z=1/a-1
        if abs(z)<1e-10: z=0.
        label.data.body=f'a = {a:.4f}   z = {z:.3f}' + ('  (interpolated)' if alpha else '')
    note=bpy.data.objects.get('ParticleSampleNote')
    if note:
        mode=obj.get('color_mode','speed')
        color=(f"Speed: 0 - {obj.get('speed_color_max',1000.):g} km/s (fixed; clipped)"
               if mode=='speed' else 'Uniform cool-white')
        note.data.body=f"Fixed-ID sample: {len(indices):,} / 1,073,741,824 particles\n{color}"

def set_appearance(mode='uniform',radius=.0003,emission_strength=1.,speed_max=1000.):
    """Change display only; cached positions, speeds and uint64 IDs are untouched."""
    if mode not in ('uniform','speed'): raise ValueError('Choose uniform or speed')
    obj=bpy.data.objects['Particles']; group=obj.modifiers['EmissivePoints'].node_group
    points=next(n for n in group.nodes if n.bl_idname=='GeometryNodeMeshToPoints')
    points.inputs['Radius'].default_value=radius
    mat=next(n for n in group.nodes if n.bl_idname=='GeometryNodeSetMaterial').inputs['Material'].default_value
    nodes=mat.node_tree.nodes; links=mat.node_tree.links
    emission=next(n for n in nodes if n.bl_idname=='ShaderNodeEmission')
    ramp=next(n for n in nodes if n.bl_idname=='ShaderNodeValToRGB')
    normal=next(n for n in nodes if n.bl_idname=='ShaderNodeMapRange')
    normal.inputs['From Min'].default_value=0.; normal.inputs['From Max'].default_value=speed_max; normal.clamp=True
    for link in list(emission.inputs['Color'].links): links.remove(link)
    if mode=='speed': links.new(ramp.outputs['Color'],emission.inputs['Color'])
    else: emission.inputs['Color'].default_value=(.48,.68,1.,1.)
    emission.inputs['Strength'].default_value=emission_strength
    obj['color_mode']=mode; obj['speed_color_max']=speed_max
    update_frame(bpy.context.scene)

def register():
    for handler in list(bpy.app.handlers.frame_change_pre):
        if getattr(handler,'__module__','')==__name__: bpy.app.handlers.frame_change_pre.remove(handler)
    bpy.app.handlers.frame_change_pre.insert(0,update_frame)

def set_cohort_size(size):
    """Switch nested quality level without changing particle identity or cache files."""
    obj=bpy.data.objects['Particles']; root=Path(bpy.path.abspath(obj['cache_root']))
    if size not in (100000,500000,1000000): raise ValueError('Choose 100000, 500000, or 1000000')
    if not (root/'cohorts'/f'particles_{size}.indices.u32').exists(): raise FileNotFoundError('Cohort mapping missing')
    old=obj.data; mesh=bpy.data.meshes.new('CanonicalParticleVertices')
    mesh.vertices.add(size); mesh.attributes.new('speed','FLOAT','POINT')
    obj.data=mesh; obj['cohort_size']=size; _cache.clear()
    register()
    bpy.context.scene.frame_set(bpy.context.scene.frame_current)
    if old.users==0: bpy.data.meshes.remove(old)

def create(root,size,snapshots,spacing=5,radius=.00045,emission_strength=2.,speed_max=1000.,interpolation=True):
    root=Path(root).resolve(); indices=np.fromfile(root/'cohorts'/f'particles_{size}.indices.u32',dtype='<u4')
    pos,speed,meta=frame_data(root,snapshots[0],indices)
    mesh=bpy.data.meshes.new('CanonicalParticleVertices'); mesh.vertices.add(size)
    mesh.vertices.foreach_set('co',pos.ravel()); mesh.update()
    attr=mesh.attributes.new('speed','FLOAT','POINT'); attr.data.foreach_set('value',speed)
    collection=bpy.data.collections.new('Particles'); bpy.context.scene.collection.children.link(collection)
    obj=bpy.data.objects.new('Particles',mesh); collection.objects.link(obj)
    obj['cache_root']=str(root); obj['cohort_size']=size; obj['snapshots']=snapshots; obj['frames_per_snapshot']=spacing
    obj['interpolation']=interpolation
    material=bpy.data.materials.new('SpeedEmission'); material.use_nodes=True
    nodes=material.node_tree.nodes; nodes.clear(); links=material.node_tree.links
    attribute=nodes.new('ShaderNodeAttribute'); attribute.attribute_name='speed'
    normal=nodes.new('ShaderNodeMapRange'); normal.inputs['From Max'].default_value=speed_max
    ramp=nodes.new('ShaderNodeValToRGB'); ramp.color_ramp.elements[0].color=(.02,.1,.4,1)
    ramp.color_ramp.elements[1].color=(1,.55,.12,1)
    emission=nodes.new('ShaderNodeEmission'); emission.inputs['Strength'].default_value=emission_strength
    out=nodes.new('ShaderNodeOutputMaterial')
    links.new(attribute.outputs['Fac'],normal.inputs['Value']); links.new(normal.outputs['Result'],ramp.inputs['Fac'])
    links.new(ramp.outputs['Color'],emission.inputs['Color']); links.new(emission.outputs[0],out.inputs['Surface'])
    group=bpy.data.node_groups.new('ParticlePoints','GeometryNodeTree')
    group.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry')
    group.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
    inp=group.nodes.new('NodeGroupInput'); out=group.nodes.new('NodeGroupOutput')
    points=group.nodes.new('GeometryNodeMeshToPoints'); points.mode='VERTICES'; points.inputs['Radius'].default_value=radius
    mat=group.nodes.new('GeometryNodeSetMaterial'); mat.inputs['Material'].default_value=material
    group.links.new(inp.outputs['Geometry'],points.inputs['Mesh'])
    group.links.new(points.outputs['Points'],mat.inputs['Geometry']); group.links.new(mat.outputs['Geometry'],out.inputs['Geometry'])
    modifier=obj.modifiers.new('EmissivePoints','NODES'); modifier.node_group=group
    register(); return obj

if __name__=='__main__':
    import argparse
    import sys
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',required=True); parser.add_argument('--size',type=int,default=1000000)
    parser.add_argument('--snapshots',nargs='+',type=int,default=list(range(57)))
    parser.add_argument('--spacing',type=int,default=5)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    create(args.root,args.size,args.snapshots,args.spacing)
    bpy.context.scene.frame_end=1+(len(args.snapshots)-1)*args.spacing
    bpy.context.scene.frame_set(1)
