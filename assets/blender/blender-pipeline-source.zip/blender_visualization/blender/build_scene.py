"""blender -b --python build_scene.py -- --root OUTPUT --size 100000 --pilot"""
import argparse
import json
import math
import os
import socket
try:
    import resource
except ImportError:
    resource=None
import sys
import time
from pathlib import Path
import bpy
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
import import_particle_animation as particles
import import_volume_animation as volumes

def main():
    startup=time.time()-float(os.environ['BLENDER_LAUNCH_EPOCH']) if 'BLENDER_LAUNCH_EPOCH' in os.environ else None
    p=argparse.ArgumentParser(); p.add_argument('--root',required=True); p.add_argument('--size',type=int)
    p.add_argument('--pilot',action='store_true'); p.add_argument('--volume',action='store_true')
    p.add_argument('--render',action='store_true'); p.add_argument('--engine')
    p.add_argument('--width',type=int); p.add_argument('--height',type=int)
    p.add_argument('--samples',type=int,default=64)
    a=p.parse_args(sys.argv[sys.argv.index('--')+1:]); root=Path(a.root).resolve()
    cfg=json.loads((root/'visualization.json').read_text()) if (root/'visualization.json').exists() else {}
    a.size=a.size or cfg.get('particles',{}).get('cohort_size',1000000)
    a.engine=a.engine or cfg.get('render',{}).get('engine','EEVEE')
    if a.engine=='EEVEE': a.engine='BLENDER_EEVEE_NEXT'
    a.width=a.width or (960 if a.pilot else cfg.get('render',{}).get('resolution_x',1920))
    a.height=a.height or (540 if a.pilot else cfg.get('render',{}).get('resolution_y',1080))
    started=time.perf_counter(); bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
    scene=bpy.context.scene; scene.render.engine=a.engine; scene.render.resolution_x=a.width; scene.render.resolution_y=a.height
    if hasattr(scene,'eevee') and hasattr(scene.eevee,'taa_render_samples'):
        scene.eevee.taa_render_samples=a.samples
        if hasattr(scene.eevee,'volumetric_tile_size'): scene.eevee.volumetric_tile_size='2'
    if a.engine=='CYCLES':
        scene.cycles.samples=32
        preferences=bpy.context.preferences.addons['cycles'].preferences
        try:
            preferences.compute_device_type='CUDA'; preferences.get_devices()
            for device in preferences.devices: device.use=device.type=='CUDA'
            scene.cycles.device='GPU' if any(d.type=='CUDA' for d in preferences.devices) else 'CPU'
        except Exception as exc: print('Cycles GPU unavailable',repr(exc),flush=True)
    scene.render.resolution_percentage=100; scene.render.fps=24; scene.render.film_transparent=False
    world=bpy.data.worlds.new('BlackSpace'); world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(0,0,0,1); scene.world=world
    snapshots=[55,56] if a.pilot else list(range(57)); spacing=cfg.get('animation',{}).get('frames_per_snapshot',5)
    opts=cfg.get('particles',{})
    obj=particles.create(root,a.size,snapshots,spacing,opts.get('point_radius',.00045),
                         opts.get('emission_strength',2.),opts.get('speed_color_max',1000.),
                         cfg.get('animation',{}).get('interpolation',True))
    imported=time.perf_counter()-started
    particles.set_appearance(opts.get('color_mode','uniform'),opts.get('point_radius',.0003),
                             opts.get('emission_strength',1.),opts.get('speed_color_max',1000.))
    scene.view_settings.exposure=cfg.get('render',{}).get('exposure',-.3)
    if a.volume or cfg.get('volume',{}).get('retain_manual_toggle',False):
        vcfg=cfg.get('volume',{})
        volumes.create(root,[56] if a.pilot else [0,28,56],spacing,
                       vcfg.get('resolution',128),vcfg.get('density_scale',.8),vcfg.get('emission_strength',3.))
        bpy.data.collections['Volume'].hide_render=not (a.volume or vcfg.get('enabled',False))
        bpy.data.collections['Volume'].hide_viewport=bpy.data.collections['Volume'].hide_render
    scene.frame_start=1; scene.frame_end=1+(len(snapshots)-1)*spacing
    scene.render.fps=max(1,round(scene.frame_end/cfg.get('animation',{}).get('duration_seconds',15)))
    bpy.ops.object.camera_add(location=(1.6,-2.2,1.25)); cam=bpy.context.object; cam.name='OrbitCamera'; scene.camera=cam
    cam.data.lens=45; cam.data.clip_start=.001; cam.data.clip_end=100
    for fraction,radius in [(0,3.8),(.4,3.3),(.7,2.6),(1,3.8)]:
        angle=-.9+fraction*.9; cam.location=(radius*math.cos(angle),radius*math.sin(angle),radius*.45)
        cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler()
        frame=round(1+fraction*(scene.frame_end-1))
        cam.keyframe_insert(data_path='location',frame=frame); cam.keyframe_insert(data_path='rotation_euler',frame=frame)
    bpy.ops.object.text_add(); text=bpy.context.object; text.name='CosmicTime'; text.parent=cam
    text.location=(-.32,.19,-1); text.rotation_euler=(0,0,0); text.scale=(.018,)*3
    labelmat=bpy.data.materials.new('Label'); labelmat.use_nodes=True
    bsdf=labelmat.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Emission Color'].default_value=(.8,.8,.8,1); bsdf.inputs['Emission Strength'].default_value=1
    text.data.materials.append(labelmat)
    note=text.copy(); note.data=text.data.copy(); scene.collection.objects.link(note)
    note.name='ParticleSampleNote'; note.location=(-.32,.162,-1); note.scale=(.010,)*3
    if cfg.get('animation',{}).get('camera_mode','fixed')=='fixed':
        cam.animation_data_clear(); radius=3.8; angle=-.9
        cam.location=(radius*math.cos(angle),radius*math.sin(angle),radius*.45)
        cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler()
    scene.render.use_lock_interface=True
    latencies=[]
    for frame in [1,2,3,scene.frame_end,1]:
        t=time.perf_counter(); scene.frame_set(frame); bpy.context.view_layer.update(); latencies.append(time.perf_counter()-t)
    dest=root/'preview'; dest.mkdir(parents=True,exist_ok=True)
    suffix=f'{a.size}_{"pilot" if a.pilot else "full"}_{a.engine}'
    if a.volume: suffix+='_hybrid'
    # Embedded bootstrap restores handlers only when trusted Python auto-run is enabled.
    bootstrap=bpy.data.texts.new('restore_animation.py'); bootstrap.use_module=True
    bootstrap.write("import sys, pathlib, bpy\nbase=pathlib.Path(bpy.path.abspath('//../../blender'))\n"
                    "sys.path.insert(0,str(base))\nimport import_particle_animation as p\np.register()\n"
                    "import import_volume_animation as v\n"
                    "if v.update_volume not in bpy.app.handlers.frame_change_pre: bpy.app.handlers.frame_change_pre.append(v.update_volume)\n")
    destblend=dest/('cosmic_evolution_demo.blend' if not a.pilot and a.engine=='BLENDER_EEVEE_NEXT' else f'cosmic_evolution_{suffix}.blend')
    # Paths are relative to output/preview, so moving the whole package is supported.
    obj['cache_root']='//..'
    for volume in bpy.data.volumes:
        if volume.filepath: volume.filepath=bpy.path.relpath(volume.filepath,start=str(dest))
    bpy.ops.wm.save_as_mainfile(filepath=str(destblend))
    rendering=None
    if a.render:
        if not a.pilot:
            # Save the requested scene resolution, but keep MVP proof renders small.
            scene.render.resolution_x=min(a.width,960); scene.render.resolution_y=min(a.height,540)
            if a.engine=='BLENDER_EEVEE_NEXT':
                scene.eevee.taa_render_samples=cfg.get('render',{}).get('preview_samples',16)
        scene.frame_set(scene.frame_end); scene.render.filepath=str(dest/f'{suffix}.png')
        t=time.perf_counter(); bpy.ops.render.render(write_still=True); rendering=time.perf_counter()-t
    peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss if resource else None
    if peak_rss is not None and sys.platform=='darwin': peak_rss/=1024
    report=dict(blender=bpy.app.version_string,size=a.size,engine=a.engine,
        startup_seconds=startup,
        hostname=socket.gethostname(),resolution=[a.width,a.height],
        actual_render_resolution=[scene.render.resolution_x,scene.render.resolution_y],
        hybrid=a.volume,
        import_seconds=imported,frame_change_seconds=latencies,peak_rss_kib=peak_rss,
        blend_bytes=destblend.stat().st_size,render_seconds=rendering,viewport_fps=None,
        viewport_note='Headless test; interactive viewport FPS not measured')
    (dest/f'performance_{suffix}.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)

if __name__=='__main__': main()
